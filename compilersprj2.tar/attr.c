/**********************************************
 
        CS415  Project 2
        Spring  2018
        Student Version
**********************************************/

#include "attr.h" 





void
printType(int i)
{
  if (i == 0)
    printf("Integer\n");
  else if (i == 1)
    printf("Boolean\n");
  else 
    printf("Type error\n");
}


int
parseType(char * str)
{
  if (strcmp(str,"integer") == 0)
    return TYPE_INT;
  else if (strcmp(str,"boolean") == 0)
    return TYPE_BOOL;
  else 
   return TYPE_ERROR;
}



